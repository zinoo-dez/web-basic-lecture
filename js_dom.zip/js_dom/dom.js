// console.log(document);
// console.log(document.head);
// console.log(document.body);
// console.log(document.title);

// document.querySelector("button").onclick = () => {
// 	document.querySelector("h1").style.color = "red";
// 	document.querySelector("h1").style.fontSize = "60px";
// 	document.querySelector("p").style.color = "blue";
// 	document.body.style.background = "#333";
// };

// let div = document.createElement("div");
// div.id = "content";
// div.className = "note";
// div.innerHTML = "<p>CreateElement example</p>";

// document.body.appendChild(div);
